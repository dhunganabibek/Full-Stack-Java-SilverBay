package org.spcore.bean;

public class Table {

	private String type;
	private int price;

	public Table() {
	}

	public Table(String type) {
		this.type = type;
	}

	public Table(int price) {
		this.price = price;
	}

	public Table(String type, int price) {
		this.type = type;
		this.price = price;
		System.out.println("-------------------------");
	}

	public String getType() {
		return type;
	}

	public int getPrice() {
		return price;
	}

	@Override
	public String toString() {
		return "Table [type=" + type + ", price=" + price + "]";
	}

}
