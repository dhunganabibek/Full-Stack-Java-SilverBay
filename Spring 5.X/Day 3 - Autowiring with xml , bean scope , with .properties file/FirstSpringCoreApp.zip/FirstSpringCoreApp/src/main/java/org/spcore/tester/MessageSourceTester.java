package org.spcore.tester;

import org.spcore.bean.Triangle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageSourceTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springWithPropertiesFile.xml");

		String dbName =	applicationContext.getMessage("mysql.dbname", null, "my default Message", null);
		System.out.println(dbName);
		
	}

}
