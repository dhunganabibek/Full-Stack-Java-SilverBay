package org.spcore.bean;

public class Wire {

	private int length;

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

//	@Override
//	public String toString() {
//		return "Wire [length=" + length + "]";
//	}

}
