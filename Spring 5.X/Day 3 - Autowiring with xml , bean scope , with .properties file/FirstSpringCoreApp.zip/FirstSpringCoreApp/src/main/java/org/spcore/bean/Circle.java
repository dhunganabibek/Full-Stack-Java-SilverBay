package org.spcore.bean;

public class Circle {

	private Point point1;

	public Point getPoint1() {
		return point1;
	}

	public void setPoint1(Point point1) {
		this.point1 = point1;
	}

	@Override
	public String toString() {
		return "Circle [point1=" + point1;
	}

}
