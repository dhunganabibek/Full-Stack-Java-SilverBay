package org.spcore.tester;

import org.spcore.bean.Table;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ConstructorInjectionTester {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springConstructorInjection.xml");

		//Table r = new Table(); //JVM
		
		Table table = (Table) applicationContext.getBean("table"); //spring container
		System.out.println(table);

		System.out.println("--------------------------------------");

		Table table2 = (Table) applicationContext.getBean("tableWithType");
		// System.out.println(table2);
		System.out.println("type of table : " + table2.getType());

	}

}
