package org.spcore.dao;

import org.spcore.bean.Calculator;

public interface JdbcDao {

	public Calculator getCalculator(int id);

}
