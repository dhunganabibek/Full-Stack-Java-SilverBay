package org.spcore.service;

import org.spcore.bean.Calculator;
import org.spcore.dao.JdbcDao;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CalculatorTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springWithJdbcTemplate.xml");
		JdbcDao dao = (JdbcDao) applicationContext.getBean("jdbcDaoImpl");
		Calculator calculator = dao.getCalculator(1);
		System.out.println(calculator);
	}

}
