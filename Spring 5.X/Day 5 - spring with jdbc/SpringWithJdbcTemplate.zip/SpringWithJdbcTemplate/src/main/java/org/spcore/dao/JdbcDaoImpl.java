package org.spcore.dao;

import org.spcore.bean.Calculator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class JdbcDaoImpl implements JdbcDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Calculator getCalculator(int id) {
		String calcType = jdbcTemplate.queryForObject("select type from calculator where id=" + id, String.class);
		Calculator calculator = new Calculator();
		calculator.setId(id);
		calculator.setType(calcType);
		return calculator;
	}

}
