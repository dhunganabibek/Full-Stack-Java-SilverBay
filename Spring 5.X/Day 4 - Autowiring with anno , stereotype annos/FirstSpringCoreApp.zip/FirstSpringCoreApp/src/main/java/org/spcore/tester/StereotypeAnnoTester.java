package org.spcore.tester;

import org.spcore.bean.SemiCircle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StereotypeAnnoTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springStereotypeAnno.xml");

		SemiCircle semiCircle = (SemiCircle) applicationContext.getBean("semiCircle");
		System.out.println(semiCircle);
	}

}
