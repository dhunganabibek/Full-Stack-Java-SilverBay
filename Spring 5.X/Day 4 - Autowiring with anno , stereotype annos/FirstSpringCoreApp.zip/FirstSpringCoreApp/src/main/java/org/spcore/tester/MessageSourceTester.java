package org.spcore.tester;

import org.spcore.bean.Triangle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MessageSourceTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springWithPropertiesFile.xml");

		String dbName =	applicationContext.getMessage("mysql.dbnam", null, "my default Message", null);
			           //applicationContext.getMessage(code, args, defaultMessage, locale)
		System.out.println(dbName);
		
	}

}
