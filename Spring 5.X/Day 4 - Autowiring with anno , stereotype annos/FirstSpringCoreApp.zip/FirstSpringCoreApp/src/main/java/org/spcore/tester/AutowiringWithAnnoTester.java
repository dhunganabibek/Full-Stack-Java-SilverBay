package org.spcore.tester;

import org.spcore.bean.Point;
import org.spcore.bean.Rectangle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutowiringWithAnnoTester {

	public static void main(String[] args) {

		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springAutowiringWithAnno.xml");

		Point point =  (Point) applicationContext.getBean("pointA");
		System.out.println(point);
		
		Rectangle rectangle =  (Rectangle) applicationContext.getBean("rectangle");
		System.out.println(rectangle);
	}

}