package org.spcore.tester;

import org.spcore.bean.Circle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutowiringByTypeTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springAutowiringByType.xml");

		Circle circle = (Circle) applicationContext.getBean("circle");
		System.out.println(circle);
	}

}
