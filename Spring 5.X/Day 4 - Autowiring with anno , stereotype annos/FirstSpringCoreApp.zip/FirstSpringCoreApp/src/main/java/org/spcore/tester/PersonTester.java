package org.spcore.tester;

import org.spcore.bean.Person;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PersonTester {

	public static void main(String[] args) {
		// step1 : obtain the ref of ApplicationContext
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springbasic.xml");

		// step 2: load the bean by using its id , here it is person in springbasic.xml
		// file
		Person person = (Person) applicationContext.getBean("person");
		System.out.println(person);
		
		System.out.println("---------------------------------");
		
		Person person2 = (Person) applicationContext.getBean("person2");
		System.out.println(person2);
	}

}
