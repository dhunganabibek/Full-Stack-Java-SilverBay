package org.spcore.tester;

import org.spcore.bean.Triangle;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutowiringByNameTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springAutowiringByName.xml");

		Triangle triangle = (Triangle) applicationContext.getBean("triangle");
		System.out.println(triangle);
	}

}
