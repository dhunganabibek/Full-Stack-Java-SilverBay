package org.spcore.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class SemiCircle {

	@Autowired
	private Point pt1;

	public Point getPt1() {
		return pt1;
	}

	public void setPt1(Point pt1) {
		this.pt1 = pt1;
	}

	@Override
	public String toString() {
		return "SemiCircle [pt1=" + pt1 + "]";
	}

}
