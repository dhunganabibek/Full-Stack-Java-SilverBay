package org.spcore.tester;

import org.spcore.bean.Wire;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class BeanScopeTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springBeanScope.xml");

		Wire wire = (Wire) applicationContext.getBean("wire");
		System.out.println(wire);
		
		Wire wire2 = (Wire) applicationContext.getBean("wire");
		System.out.println(wire2);
		
		Wire wire3 = (Wire) applicationContext.getBean("wire");
		System.out.println(wire3);
	}

}
