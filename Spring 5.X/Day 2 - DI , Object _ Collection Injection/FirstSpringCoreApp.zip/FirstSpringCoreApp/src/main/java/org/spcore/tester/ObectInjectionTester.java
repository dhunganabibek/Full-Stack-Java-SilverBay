package org.spcore.tester;

import org.spcore.bean.Line;
import org.spcore.bean.Point;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ObectInjectionTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springObjectInjection.xml");

		Point point1 =	(Point) applicationContext.getBean("p1");
		System.out.println(point1);
		Point point2 =	(Point) applicationContext.getBean("p2");
		System.out.println(point2);
		
		Line line=	(Line) applicationContext.getBean("line");
		System.out.println(line);
	}

}
