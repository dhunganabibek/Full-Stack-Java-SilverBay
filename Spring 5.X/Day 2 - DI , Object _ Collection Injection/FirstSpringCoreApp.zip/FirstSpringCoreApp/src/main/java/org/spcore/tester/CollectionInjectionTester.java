package org.spcore.tester;

import org.spcore.bean.Line;
import org.spcore.bean.Point;
import org.spcore.bean.Square;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CollectionInjectionTester {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springObjectInjection.xml");

		Square square = (Square) applicationContext.getBean("square");
		System.out.println(square);
	}

}
