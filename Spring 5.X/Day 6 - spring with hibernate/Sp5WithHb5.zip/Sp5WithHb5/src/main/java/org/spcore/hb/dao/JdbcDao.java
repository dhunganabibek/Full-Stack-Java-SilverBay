package org.spcore.hb.dao;

import org.spcore.hb.entity.Plant;

public interface JdbcDao {

	public int save(Plant plant);

}
