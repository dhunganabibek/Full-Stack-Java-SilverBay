package com.springboot.coronadetector.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.coronadetector.dao.UserDao;
import com.springboot.coronadetector.dto.UserDTO;
import com.springboot.coronadetector.exception.LoginException;
import com.springboot.coronadetector.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public UserDTO login(UserDTO userDTO) {
		Optional<User> opUser = userDao.findByUsernameAndPasswordAndUserType(userDTO.getUsername(),
				userDTO.getPassword(), userDTO.getUserType());
		if (opUser.isPresent()) {
			User dbUser = opUser.get();
			userDTO.setId(dbUser.getId());
			userDTO.setUsername(dbUser.getUsername());
			userDTO.setPassword(dbUser.getPassword());
			userDTO.setUserType(dbUser.getUserType());
			userDTO.setSubscriptionType(dbUser.getSubscriptionType());
			return userDTO;
		} else {
			throw new LoginException("Wrong Credentials.Please try again.");
		}
	}

}
