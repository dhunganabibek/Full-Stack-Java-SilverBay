package com.springboot.coronadetector.service;

import com.springboot.coronadetector.dto.UserDTO;

public interface UserService {

	public UserDTO login(UserDTO userDTO);

}
