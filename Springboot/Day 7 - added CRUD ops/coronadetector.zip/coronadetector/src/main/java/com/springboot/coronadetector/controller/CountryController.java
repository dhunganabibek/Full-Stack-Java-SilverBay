package com.springboot.coronadetector.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.coronadetector.dto.CoronaDetectorResponseDTO;
import com.springboot.coronadetector.dto.CountryDTO;
import com.springboot.coronadetector.service.CountryService;

@RestController
public class CountryController {

	@Autowired
	private CountryService countryService;

	@PostMapping("/country")
	public CoronaDetectorResponseDTO saveCountry(@RequestBody CountryDTO countryDTO) {
		CountryDTO respCountryDTO = countryService.saveCountry(countryDTO);
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.OK.value()));
		response.setDate(new Date());
		response.setError(null);
		response.setData(respCountryDTO);
		response.setPath("Not sure , It is the HW !!!");

		return response;
	}

}
