package com.springboot.coronadetector;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoronadetectorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoronadetectorApplication.class, args);
	}

}
