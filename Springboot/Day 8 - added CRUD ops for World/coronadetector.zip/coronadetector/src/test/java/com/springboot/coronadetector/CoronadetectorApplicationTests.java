package com.springboot.coronadetector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoronadetectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
