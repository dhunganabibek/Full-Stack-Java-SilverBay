package com.springboot.coronadetector.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.coronadetector.dto.CoronaDetectorResponseDTO;
import com.springboot.coronadetector.dto.WorldDTO;
import com.springboot.coronadetector.service.WorldService;

@RestController
public class WorldController {

	@Autowired
	private WorldService worldService;

	@PostMapping("/world")
	public CoronaDetectorResponseDTO saveCountry(@RequestBody WorldDTO worldDTO) {

		WorldDTO respWorldDTO = worldService.saveWorld(worldDTO);
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.OK.value()));
		response.setDate(new Date());
		response.setError(null);
		response.setData(respWorldDTO);
		response.setPath("Not sure , It is the HW !!!");

		return response;
	}

}
