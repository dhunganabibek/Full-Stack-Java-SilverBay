package com.springboot.coronadetector.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.springboot.coronadetector.dto.CoronaDetectorResponseDTO;
import com.springboot.coronadetector.exception.LoginException;

@ControllerAdvice
public class CoronaDetectorExceptionController {

	@ExceptionHandler(value = LoginException.class)
	public ResponseEntity<CoronaDetectorResponseDTO> loginExceptionHandler(LoginException loginException) {
		System.out.println("from loginException !!!");
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.NOT_FOUND.value()));
		response.setDate(new Date());
		response.setData(null);
		Map<String, String> errorResponse = new HashMap<String, String>();
		errorResponse.put("errorCode", String.valueOf(HttpStatus.NOT_FOUND.value()));
		errorResponse.put("errorMsg", loginException.getExceptionMsg());
		response.setError(errorResponse);
		response.setPath("Not sure , It is the HW !!!");
		return new ResponseEntity<CoronaDetectorResponseDTO>(response,HttpStatus.NOT_FOUND);
	}

}
