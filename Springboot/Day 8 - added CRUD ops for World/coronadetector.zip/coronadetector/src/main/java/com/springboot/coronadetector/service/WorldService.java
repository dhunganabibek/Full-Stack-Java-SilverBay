package com.springboot.coronadetector.service;

import com.springboot.coronadetector.dto.WorldDTO;

public interface WorldService {

	public WorldDTO getWorld(int id);

	public WorldDTO saveWorld(WorldDTO worldDTO);

	public WorldDTO updateWorld(WorldDTO worldDTO);

	public WorldDTO deleteWorld(int id);

}
