package com.springboot.coronadetector.mapper;

import com.springboot.coronadetector.dto.WorldDTO;
import com.springboot.coronadetector.model.World;

public class WorldMapper {

	public static World toWorldEntity(WorldDTO worldDTO) {
		World world = new World();
		world.setName(worldDTO.getName());
		return world;
	}

	public static WorldDTO toWorldDTO(World world) {
		WorldDTO respWorldDTO = new WorldDTO();
		respWorldDTO.setId(world.getId());
		respWorldDTO.setName(world.getName());
		return respWorldDTO;
	}

}
