package com.springboot.coronadetector.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.coronadetector.dao.UserDao;
import com.springboot.coronadetector.dao.WorldDao;
import com.springboot.coronadetector.dto.CaseStatsDTO;
import com.springboot.coronadetector.dto.CountryDTO;
import com.springboot.coronadetector.dto.WorldDTO;
import com.springboot.coronadetector.mapper.CaseStatsMapper;
import com.springboot.coronadetector.mapper.CountryMapper;
import com.springboot.coronadetector.mapper.WorldMapper;
import com.springboot.coronadetector.model.CaseStats;
import com.springboot.coronadetector.model.Country;
import com.springboot.coronadetector.model.User;
import com.springboot.coronadetector.model.World;

@Service
public class WorldServiceImpl implements WorldService {

	@Autowired
	private WorldDao worldDao;

	@Autowired
	private UserDao userDao;

	@Override
	public WorldDTO getWorld(int id, String username, String accessToken) {
		WorldDTO worldDTO = new WorldDTO();
		Optional<User> opUser = userDao.findByUsernameAndAccessToken(username, accessToken);
		if (opUser.isPresent()) {
			Optional<World> opWorld = worldDao.findById(id);
			if (opWorld.isPresent()) {
				World world = opWorld.get();
				worldDTO = WorldMapper.toWorldDTO(world);
				List<CountryDTO> countryDTOs = new ArrayList<CountryDTO>();
				for (Country country : world.getCountries()) {
					CountryDTO countryDTO = CountryMapper.toCountryDTO(country);
					CaseStatsDTO caseStatsDTO = CaseStatsMapper.toCaseStatsDTO(country.getCaseStats());
					countryDTO.setCaseStats(caseStatsDTO);
					countryDTOs.add(countryDTO);
				}
				worldDTO.setCountryList(countryDTOs);
			}
		} else {
			System.out.println("username and access token are not matching!!");
		}
		return worldDTO;
	}

	@Override
	public WorldDTO saveWorld(WorldDTO worldDTO) {
		World world = WorldMapper.toWorldEntity(worldDTO);
		List<CountryDTO> countryDTOs = worldDTO.getCountryList();
		List<Country> countries = new ArrayList<Country>();
		for (CountryDTO countryDTO : countryDTOs) {
			Country country = CountryMapper.toCountryEntity(countryDTO);
			CaseStats caseStats = CaseStatsMapper.toCaseStatsEntity(countryDTO.getCaseStats());
			country.setCaseStats(caseStats);
			countries.add(country);
		}
		world.setCountries(countries);
		World dbWorld = worldDao.save(world);
		WorldDTO respWorldDTO = WorldMapper.toWorldDTO(dbWorld);
		List<Country> dbCountries = dbWorld.getCountries();
		List<CountryDTO> respCountries = new ArrayList<CountryDTO>();
		for (Country dbCountry : dbCountries) {
			CountryDTO respCountryDTO = CountryMapper.toCountryDTO(dbCountry);
			CaseStatsDTO respCaseStatsDTO = CaseStatsMapper.toCaseStatsDTO(dbCountry.getCaseStats());
			respCountryDTO.setCaseStats(respCaseStatsDTO);
			respCountries.add(respCountryDTO);
		}
		respWorldDTO.setCountryList(respCountries);
		return respWorldDTO;
	}

	@Override
	public WorldDTO updateWorld(WorldDTO worldDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public WorldDTO deleteWorld(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<WorldDTO> getAllWorld() {
		List<World> worlds = worldDao.findAll();
		List<WorldDTO> worldDTOs = new ArrayList<WorldDTO>();
		List<CountryDTO> countryDTOs = new ArrayList<CountryDTO>();
		for (World world : worlds) {
			WorldDTO worldDTO = WorldMapper.toWorldDTO(world);
			for (Country country : world.getCountries()) {
				CountryDTO countryDTO = CountryMapper.toCountryDTO(country);
				CaseStatsDTO caseStatsDTO = CaseStatsMapper.toCaseStatsDTO(country.getCaseStats());
				countryDTO.setCaseStats(caseStatsDTO);
				countryDTOs.add(countryDTO);
			}
			worldDTO.setCountryList(countryDTOs);
			worldDTOs.add(worldDTO);
		}
		return worldDTOs;
	}

}
