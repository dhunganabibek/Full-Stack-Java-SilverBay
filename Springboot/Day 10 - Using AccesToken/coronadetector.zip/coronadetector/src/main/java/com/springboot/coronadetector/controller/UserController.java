package com.springboot.coronadetector.controller;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.coronadetector.dto.CoronaDetectorResponseDTO;
import com.springboot.coronadetector.dto.UserDTO;
import com.springboot.coronadetector.service.UserService;
import com.springboot.coronadetector.utils.AppConstants;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

@RestController
@RequestMapping(AppConstants.BASE_URI)
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private HttpServletRequest request;

	@PostMapping(AppConstants.LOGIN_ROOT_ENDPOINT)
	public ResponseEntity<CoronaDetectorResponseDTO> login(@RequestBody UserDTO userDTO) {
		UserDTO responseUserDTO = userService.login(userDTO, request);
		HttpHeaders headers = new HttpHeaders();
		headers.set("accessToken", responseUserDTO.getAccessToken());
		
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.OK.value()));
		response.setDate(new Date());
		response.setError(null);
		response.setData(responseUserDTO);
		response.setPath("Not sure , It is the HW !!!");

		return ResponseEntity.ok().headers(headers).body(response);
	}

//	@GetMapping("/testapi")
//	public void testAPi() {
//		try {
//			dummy();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
//	
//	private void dummy() throws IOException {
//		OkHttpClient client = new OkHttpClient();
//		MediaType mediaType = MediaType.parse("application/json");
//		com.squareup.okhttp.RequestBody body = com.squareup.okhttp.RequestBody.create(mediaType,
//				"{\r\n    \"username\":\"Kiriti\",\r\n    \"password\":\"12345\",\r\n    \"userType\":\"Official\"\r\n}");
//		Request request = new Request.Builder().url("http://localhost:8080/api/v1/login").method("POST", body)
//				.addHeader("Content-Type", "application/json").build();
//		Response response = client.newCall(request).execute();
//		System.out.println(response.body());
//	}

}
