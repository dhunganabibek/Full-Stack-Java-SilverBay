package com.springboot.coronadetector.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.coronadetector.model.User;
import com.springboot.coronadetector.model.World;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {

	public Optional<User> findByUsernameAndPasswordAndUserType(String username, String password, String userType);

	public Optional<User> findByUsernameAndAccessToken(String username, String accessToken);

}
