package com.springboot.coronadetector.service;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.coronadetector.dao.UserDao;
import com.springboot.coronadetector.dto.UserDTO;
import com.springboot.coronadetector.exception.LoginException;
import com.springboot.coronadetector.mapper.UserMapper;
import com.springboot.coronadetector.model.User;
import com.springboot.coronadetector.utils.CoronoDetectorUtils;
import com.springboot.coronadetector.utils.TokenResponse;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public UserDTO login(UserDTO userDTO, HttpServletRequest request) {
		UserDTO respUserDto = new UserDTO();
		try {
			Optional<User> opUser = userDao.findByUsernameAndPasswordAndUserType(userDTO.getUsername(),
					userDTO.getPassword(), userDTO.getUserType());
			if (opUser.isPresent()) {
				User dbUser = opUser.get();
				respUserDto = UserMapper.toUserDTO(dbUser);
				TokenResponse tokenResponse = CoronoDetectorUtils.getAccessToken(request);
				dbUser.setAccessToken(tokenResponse.getAccess_token());
				User respUserDb = userDao.save(dbUser);
				respUserDto = UserMapper.toUserDTO(respUserDb);
			} else {
				throw new LoginException("Wrong Credentials.Please try again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return respUserDto;
	}

}
