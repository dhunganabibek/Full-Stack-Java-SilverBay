package com.springboot.coronadetector.mapper;

import com.springboot.coronadetector.dto.UserDTO;
import com.springboot.coronadetector.model.User;

public class UserMapper {

	public static User toUserEntity(UserDTO userDTO) {
		User user = new User();
		user.setId(userDTO.getId());
		user.setUsername(userDTO.getUsername());
		user.setPassword(userDTO.getPassword());
		user.setUserType(userDTO.getUserType());
		user.setSubscriptionType(userDTO.getSubscriptionType());
		user.setAccessToken(userDTO.getAccessToken());
		return user;
	}

	public static UserDTO toUserDTO(User user) {
		UserDTO userDTO = new UserDTO();
		userDTO.setId(user.getId());
		userDTO.setUsername(user.getUsername());
		userDTO.setPassword(user.getPassword());
		userDTO.setUserType(user.getUserType());
		userDTO.setSubscriptionType(user.getSubscriptionType());
		userDTO.setAccessToken(user.getAccessToken());
		return userDTO;
	}

}
