package com.springboot.coronadetector.service;

import java.util.List;

import com.springboot.coronadetector.dto.WorldDTO;

public interface WorldService {

	public WorldDTO getWorld(int id, String username, String accessToken);

	public WorldDTO saveWorld(WorldDTO worldDTO);

	public WorldDTO updateWorld(WorldDTO worldDTO);

	public WorldDTO deleteWorld(int id);

	public List<WorldDTO> getAllWorld();

}
