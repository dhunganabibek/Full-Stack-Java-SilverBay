package com.springboot.coronadetector.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;

import com.springboot.coronadetector.utils.AppConstants;

@Configuration
@EnableResourceServer
public class ResourceServerConfiguration extends ResourceServerConfigurerAdapter {

	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.resourceId(AppConstants.SERVER_RESOURCE_ID);
	}

	// white listing IP's / URL's
	@Override
	public void configure(HttpSecurity http) throws Exception {
		http.authorizeRequests().antMatchers(AppConstants.BASE_URI + AppConstants.COUNTRY_ROOT_ENDPOINT).permitAll() // api/v1/country
								.antMatchers(AppConstants.BASE_URI + AppConstants.LOGIN_ROOT_ENDPOINT).permitAll() // api/v1/login
								.antMatchers(AppConstants.BASE_URI + AppConstants.WORLD_ROOT_ENDPOINT).permitAll() // api/v1/world
								.antMatchers(AppConstants.BASE_URI + AppConstants.GET_WORLD_ENDPOINT).permitAll() // api/v1/world/worldId
								.antMatchers(AppConstants.BASE_URI + "/testapi").permitAll() // api/v1/login
								.antMatchers("/api/v1/**").authenticated();
	}

}
