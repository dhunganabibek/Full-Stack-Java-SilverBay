package com.springboot.coronadetector.service;

import javax.servlet.http.HttpServletRequest;

import com.springboot.coronadetector.dto.UserDTO;

public interface UserService {

	public UserDTO login(UserDTO userDTO, HttpServletRequest request);

}
