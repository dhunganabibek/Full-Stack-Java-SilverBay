package com.springboot.coronadetector.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.coronadetector.dto.CoronaDetectorResponseDTO;
import com.springboot.coronadetector.dto.WorldDTO;
import com.springboot.coronadetector.service.WorldService;
import com.springboot.coronadetector.utils.AppConstants;

@RestController
@RequestMapping(AppConstants.BASE_URI)
public class WorldController {

	@Autowired
	private WorldService worldService;

	@Autowired
	private HttpServletRequest httpServletRequest;

	@PostMapping(AppConstants.WORLD_ROOT_ENDPOINT)
	public CoronaDetectorResponseDTO saveWorld(@RequestBody WorldDTO worldDTO) {

		WorldDTO respWorldDTO = worldService.saveWorld(worldDTO);
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.OK.value()));
		response.setDate(new Date());
		response.setError(null);
		response.setData(respWorldDTO);
		response.setPath("Not sure , It is the HW !!!");

		return response;
	}

	@GetMapping(AppConstants.WORLD_ROOT_ENDPOINT)
	public ResponseEntity<CoronaDetectorResponseDTO> getAllWorldEntries() {

		List<WorldDTO> worldDTOs = worldService.getAllWorld();
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.OK.value()));
		response.setDate(new Date());
		response.setError(null);
		response.setData(worldDTOs);
		response.setPath("Not sure , It is the HW !!!");

		return ResponseEntity.ok().body(response);
	}

	@GetMapping(AppConstants.GET_WORLD_ENDPOINT)
	public ResponseEntity<CoronaDetectorResponseDTO> getWorld(@RequestParam String worldId) {
		String accessToken = httpServletRequest.getHeader("accessToken");
		String username = httpServletRequest.getHeader("username");
		WorldDTO worldDTO = worldService.getWorld(Integer.parseInt(worldId), username, accessToken);
		CoronaDetectorResponseDTO response = new CoronaDetectorResponseDTO();
		response.setStatus(String.valueOf(HttpStatus.OK.value()));
		response.setDate(new Date());
		response.setError(null);
		response.setData(worldDTO);
		response.setPath("Not sure , It is the HW !!!");
		return ResponseEntity.ok().body(response);
	}

}
