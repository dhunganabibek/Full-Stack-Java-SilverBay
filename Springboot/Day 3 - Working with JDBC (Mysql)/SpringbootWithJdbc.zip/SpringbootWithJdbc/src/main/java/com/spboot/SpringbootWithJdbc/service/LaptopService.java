package com.spboot.SpringbootWithJdbc.service;

import com.spboot.SpringbootWithJdbc.dto.LaptopDTO;

public interface LaptopService {

	public LaptopDTO getLaptop(int id);

}
