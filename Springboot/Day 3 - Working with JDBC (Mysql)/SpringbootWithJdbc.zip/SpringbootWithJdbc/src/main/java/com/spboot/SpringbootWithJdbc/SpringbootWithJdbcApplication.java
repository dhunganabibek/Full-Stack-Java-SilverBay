package com.spboot.SpringbootWithJdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootWithJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootWithJdbcApplication.class, args);
	}

}
