package com.springboot.coronadetector.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.coronadetector.dto.UserDTO;
import com.springboot.coronadetector.service.UserService;

@RestController
public class UserController {

	@Autowired
	private UserService userService;

	@PostMapping("/login")
	public UserDTO login(@RequestBody UserDTO userDTO) {
		return userService.login(userDTO);
	}

}
