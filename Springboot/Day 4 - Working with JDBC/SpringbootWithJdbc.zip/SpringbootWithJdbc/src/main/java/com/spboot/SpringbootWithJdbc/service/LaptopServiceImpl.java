package com.spboot.SpringbootWithJdbc.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spboot.SpringbootWithJdbc.dao.LaptopDao;
import com.spboot.SpringbootWithJdbc.dto.LaptopDTO;
import com.spboot.SpringbootWithJdbc.model.Laptop;

@Service
public class LaptopServiceImpl implements LaptopService {

	@Autowired
	private LaptopDao laptopDao;

	@Override
	public LaptopDTO getLaptop(int id) {
		Optional<Laptop> opLaptop = laptopDao.findById(id);
		LaptopDTO laptopDTO = new LaptopDTO();
		if (opLaptop.isPresent()) {
			Laptop laptop = opLaptop.get();
			laptopDTO.setId(laptop.getId());
			laptopDTO.setName(laptop.getName());
			laptopDTO.setBrand(laptop.getBrand());
		}
		return laptopDTO;
	}

	@Override
	public LaptopDTO saveLaptop(LaptopDTO laptopDTO) {
		Laptop laptop = new Laptop();
		laptop.setName(laptopDTO.getName());
		laptop.setBrand(laptopDTO.getBrand());

		Laptop resLaptop = laptopDao.save(laptop); // INSERT

		LaptopDTO resLaptopDTO = new LaptopDTO();
		resLaptopDTO.setId(resLaptop.getId());
		resLaptopDTO.setName(resLaptop.getName());
		resLaptopDTO.setBrand(resLaptop.getBrand());

		return resLaptopDTO;
	}

	@Override
	public LaptopDTO updateLaptop(LaptopDTO laptopDTO) {
		Optional<Laptop> opLaptop = laptopDao.findById(laptopDTO.getId());
		LaptopDTO resLaptopDTO = new LaptopDTO();
		if (opLaptop.isPresent()) {
			Laptop laptop = new Laptop();
			laptop.setId(laptopDTO.getId());
			laptop.setName(laptopDTO.getName());
			laptop.setBrand(laptopDTO.getBrand());

			Laptop resLaptop = laptopDao.save(laptop); // UPDATE

			resLaptopDTO.setId(resLaptop.getId());
			resLaptopDTO.setName(resLaptop.getName());
			resLaptopDTO.setBrand(resLaptop.getBrand());
		} else {
			return resLaptopDTO;
		}

		return resLaptopDTO;
	}

	@Override
	public LaptopDTO deleteLaptop(int id) {
		Optional<Laptop> opLaptop = laptopDao.findById(id);
		LaptopDTO laptopDTO = new LaptopDTO();
		if (opLaptop.isPresent()) {
			Laptop laptop = opLaptop.get();
			laptopDTO.setId(laptop.getId());
			laptopDTO.setName(laptop.getName());
			laptopDTO.setBrand(laptop.getBrand());
			laptopDao.deleteById(id);
		}
		return laptopDTO;
	}

	@Override
	public LaptopDTO getLaptopByName(String name) {
		Optional<Laptop> opLaptop = laptopDao.findByName(name);
		LaptopDTO laptopDTO = new LaptopDTO();
		if (opLaptop.isPresent()) {
			Laptop laptop = opLaptop.get();
			laptopDTO.setId(laptop.getId());
			laptopDTO.setName(laptop.getName());
			laptopDTO.setBrand(laptop.getBrand());
		}
		return laptopDTO;
	}

}
