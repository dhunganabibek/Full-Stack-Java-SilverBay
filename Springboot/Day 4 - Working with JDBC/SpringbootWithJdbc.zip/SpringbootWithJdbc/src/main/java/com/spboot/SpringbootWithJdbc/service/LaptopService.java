package com.spboot.SpringbootWithJdbc.service;

import com.spboot.SpringbootWithJdbc.dto.LaptopDTO;

public interface LaptopService {

	public LaptopDTO getLaptop(int id);

	public LaptopDTO saveLaptop(LaptopDTO dto);

	public LaptopDTO updateLaptop(LaptopDTO dto);

	public LaptopDTO deleteLaptop(int id);

	public LaptopDTO getLaptopByName(String name);

}
