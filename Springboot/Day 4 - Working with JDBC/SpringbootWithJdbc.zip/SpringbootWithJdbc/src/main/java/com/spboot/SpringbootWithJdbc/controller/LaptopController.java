package com.spboot.SpringbootWithJdbc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.spboot.SpringbootWithJdbc.dto.LaptopDTO;
import com.spboot.SpringbootWithJdbc.service.LaptopService;

@RestController
public class LaptopController {

	@Autowired
	private LaptopService laptopService;

	@GetMapping("/getLaptop/{laptopId}")
	public LaptopDTO getlaptop(@PathVariable String laptopId) {
		return laptopService.getLaptop(Integer.parseInt(laptopId));
	}

	@PostMapping("/saveLaptop")
	public LaptopDTO savelaptop(@RequestBody LaptopDTO laptopDTO) {
		return laptopService.saveLaptop(laptopDTO);
	}

	@PutMapping("/updateLaptop")
	public LaptopDTO updateLaptop(@RequestBody LaptopDTO laptopDTO) {
		return laptopService.updateLaptop(laptopDTO);
	}

	@DeleteMapping("/deleteLaptop/{laptopId}")
	public LaptopDTO deleteLaptop(@PathVariable String laptopId) {
		return laptopService.deleteLaptop(Integer.parseInt(laptopId));
	}
	
	@GetMapping("/getLaptopByName/{laptopName}")
	public LaptopDTO getLaptopByName(@PathVariable String laptopName) {
		return laptopService.getLaptopByName(laptopName);
	}

}
