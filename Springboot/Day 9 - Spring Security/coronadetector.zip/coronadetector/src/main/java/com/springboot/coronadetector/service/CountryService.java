package com.springboot.coronadetector.service;

import com.springboot.coronadetector.dto.CountryDTO;

public interface CountryService {

	public CountryDTO getCountry(int id);

	public CountryDTO saveCountry(CountryDTO countryDTO);

	public CountryDTO updateCountry(CountryDTO countryDTO);

	public CountryDTO deleteCountry(int id);

}
