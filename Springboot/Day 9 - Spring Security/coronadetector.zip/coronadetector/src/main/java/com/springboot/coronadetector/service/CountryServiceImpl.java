package com.springboot.coronadetector.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.coronadetector.dao.CountryDao;
import com.springboot.coronadetector.dto.CaseStatsDTO;
import com.springboot.coronadetector.dto.CountryDTO;
import com.springboot.coronadetector.model.CaseStats;
import com.springboot.coronadetector.model.Country;

@Service
public class CountryServiceImpl implements CountryService {

	@Autowired
	private CountryDao countryDao;

	@Override
	public CountryDTO getCountry(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountryDTO saveCountry(CountryDTO countryDTO) {
		Country country = new Country();
		country.setName(countryDTO.getName());
		country.setState(countryDTO.getState());
		country.setCity(countryDTO.getCity());
		country.setCounty(countryDTO.getCounty());

		CaseStats caseStats = new CaseStats();
		caseStats.setVariant(countryDTO.getCaseStats().getVariant());
		caseStats.setActive(countryDTO.getCaseStats().getActive());
		caseStats.setClosed(countryDTO.getCaseStats().getClosed());

		country.setCaseStats(caseStats);

		Country dbCountry = countryDao.save(country);

		CountryDTO respCountryDTO = new CountryDTO();
		respCountryDTO.setId(dbCountry.getId());
		respCountryDTO.setName(dbCountry.getName());
		respCountryDTO.setState(dbCountry.getState());
		respCountryDTO.setCity(dbCountry.getCity());
		respCountryDTO.setCounty(dbCountry.getCounty());

		CaseStatsDTO respCaseStatsDTO = new CaseStatsDTO();
		respCaseStatsDTO.setId(dbCountry.getCaseStats().getId());
		respCaseStatsDTO.setVariant(dbCountry.getCaseStats().getVariant());
		respCaseStatsDTO.setActive(dbCountry.getCaseStats().getActive());
		respCaseStatsDTO.setClosed(dbCountry.getCaseStats().getClosed());

		respCountryDTO.setCaseStats(respCaseStatsDTO);

		return respCountryDTO;
	}

	@Override
	public CountryDTO updateCountry(CountryDTO countryDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CountryDTO deleteCountry(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
