package com.springboot.coronadetector.service;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.coronadetector.dao.UserDao;
import com.springboot.coronadetector.dto.UserDTO;
import com.springboot.coronadetector.exception.LoginException;
import com.springboot.coronadetector.model.User;
import com.springboot.coronadetector.utils.CoronoDetectorUtils;
import com.springboot.coronadetector.utils.TokenResponse;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;

	@Override
	public UserDTO login(UserDTO userDTO, HttpServletRequest request) {
		UserDTO respUserDto = new UserDTO();
		try {
			Optional<User> opUser = userDao.findByUsernameAndPasswordAndUserType(userDTO.getUsername(),
					userDTO.getPassword(), userDTO.getUserType());
			if (opUser.isPresent()) {
				User dbUser = opUser.get();
				respUserDto.setId(dbUser.getId());
				respUserDto.setUsername(dbUser.getUsername());
				respUserDto.setPassword(dbUser.getPassword());
				respUserDto.setUserType(dbUser.getUserType());
				respUserDto.setSubscriptionType(dbUser.getSubscriptionType());
				TokenResponse tokenResponse = CoronoDetectorUtils.getAccessToken(request);
				System.out.println(tokenResponse);
			} else {
				throw new LoginException("Wrong Credentials.Please try again.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return respUserDto;
	}

}
