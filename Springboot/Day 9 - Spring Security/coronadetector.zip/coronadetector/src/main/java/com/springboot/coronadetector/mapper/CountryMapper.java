package com.springboot.coronadetector.mapper;

import com.springboot.coronadetector.dto.CountryDTO;
import com.springboot.coronadetector.model.Country;

public class CountryMapper {

	public static Country toCountryEntity(CountryDTO countryDTO) {
		Country country = new Country();
		country.setName(countryDTO.getName());
		country.setState(countryDTO.getState());
		country.setCity(countryDTO.getCity());
		country.setCounty(countryDTO.getCounty());
		return country;
	}

	public static CountryDTO toCountryDTO(Country country) {
		CountryDTO respCountryDTO = new CountryDTO();
		respCountryDTO.setId(country.getId());
		respCountryDTO.setName(country.getName());
		respCountryDTO.setState(country.getState());
		respCountryDTO.setCity(country.getCity());
		respCountryDTO.setCounty(country.getCounty());
		return respCountryDTO;
	}

}
