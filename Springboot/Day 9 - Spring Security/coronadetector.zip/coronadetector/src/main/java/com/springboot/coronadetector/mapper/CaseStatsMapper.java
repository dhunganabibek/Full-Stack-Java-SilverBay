package com.springboot.coronadetector.mapper;

import com.springboot.coronadetector.dto.CaseStatsDTO;
import com.springboot.coronadetector.model.CaseStats;

public class CaseStatsMapper {

	public static CaseStats toCaseStatsEntity(CaseStatsDTO caseStatsDTO) {
		CaseStats caseStats = new CaseStats();
		caseStats.setVariant(caseStatsDTO.getVariant());
		caseStats.setActive(caseStatsDTO.getActive());
		caseStats.setClosed(caseStatsDTO.getClosed());
		return caseStats;
	}

	public static CaseStatsDTO toCaseStatsDTO(CaseStats caseStats) {
		CaseStatsDTO respCaseStatsDTO = new CaseStatsDTO();
		respCaseStatsDTO.setId(caseStats.getId());
		respCaseStatsDTO.setVariant(caseStats.getVariant());
		respCaseStatsDTO.setActive(caseStats.getActive());
		respCaseStatsDTO.setClosed(caseStats.getClosed());
		return respCaseStatsDTO;
	}

}
