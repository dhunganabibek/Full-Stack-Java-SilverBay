package com.springboot.coronadetector.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.coronadetector.dao.WorldDao;
import com.springboot.coronadetector.dto.CaseStatsDTO;
import com.springboot.coronadetector.dto.CountryDTO;
import com.springboot.coronadetector.dto.WorldDTO;
import com.springboot.coronadetector.mapper.CaseStatsMapper;
import com.springboot.coronadetector.mapper.CountryMapper;
import com.springboot.coronadetector.mapper.WorldMapper;
import com.springboot.coronadetector.model.CaseStats;
import com.springboot.coronadetector.model.Country;
import com.springboot.coronadetector.model.World;

@Service
public class WorldServiceImpl implements WorldService {

	@Autowired
	private WorldDao worldDao;

	@Override
	public WorldDTO getWorld(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public WorldDTO saveWorld(WorldDTO worldDTO) {
		World world = WorldMapper.toWorldEntity(worldDTO);
		List<CountryDTO> countryDTOs = worldDTO.getCountryList();
		List<Country> countries = new ArrayList<Country>();
		for (CountryDTO countryDTO : countryDTOs) {
			Country country = CountryMapper.toCountryEntity(countryDTO);
			CaseStats caseStats = CaseStatsMapper.toCaseStatsEntity(countryDTO.getCaseStats());
			country.setCaseStats(caseStats);
			countries.add(country);
		}
		world.setCountries(countries);
		World dbWorld = worldDao.save(world);
		WorldDTO respWorldDTO = WorldMapper.toWorldDTO(dbWorld);
		List<Country> dbCountries = dbWorld.getCountries();
		List<CountryDTO> respCountries = new ArrayList<CountryDTO>();
		for (Country dbCountry : dbCountries) {
			CountryDTO respCountryDTO = CountryMapper.toCountryDTO(dbCountry);
			CaseStatsDTO respCaseStatsDTO = CaseStatsMapper.toCaseStatsDTO(dbCountry.getCaseStats());
			respCountryDTO.setCaseStats(respCaseStatsDTO);
			respCountries.add(respCountryDTO);
		}
		respWorldDTO.setCountryList(respCountries);
		return respWorldDTO;
	}

	@Override
	public WorldDTO updateWorld(WorldDTO worldDTO) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public WorldDTO deleteWorld(int id) {
		// TODO Auto-generated method stub
		return null;
	}

}
