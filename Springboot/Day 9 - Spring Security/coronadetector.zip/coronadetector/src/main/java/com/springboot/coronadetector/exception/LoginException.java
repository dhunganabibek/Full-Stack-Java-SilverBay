package com.springboot.coronadetector.exception;

public class LoginException extends RuntimeException {

	private String exceptionMsg;

	public LoginException() {
	}

	public LoginException(String exceptionMsg) {
		super(exceptionMsg);
		this.exceptionMsg = exceptionMsg;
	}

	public String getExceptionMsg() {
		return exceptionMsg;
	}

}
