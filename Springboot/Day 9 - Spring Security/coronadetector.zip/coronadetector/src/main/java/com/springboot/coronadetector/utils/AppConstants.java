package com.springboot.coronadetector.utils;

public class AppConstants {

	public final static String BASE_URI = "/api/v1";
	public final static String COUNTRY_ROOT_ENDPOINT = "/country";

	public final static String WORLD_ROOT_ENDPOINT = "/world";

	public final static String LOGIN_ROOT_ENDPOINT = "/login";

	public final static String SUCCESS = "Success";

	public static final String SERVER_RESOURCE_ID = "coronodetector-backend-api";

	public static final String OAUTH_CLIENT_ID = "coronodetector";
	public static final String OAUTH_CLIENT_SECRET = "Password@1234";
	public static final String OAUTH_AUTH_TYPE = "password"; // authenticating user by password
	public static final String OAUTH_GRANT_TYPE = "client_credentials"; // allowing user as per there grant type
	public static final String OAUTH_REFRESH_TOKEN = "refresh_token"; // allowing user as per there grant type by using
																		// refreshToken
	public static final String SCOPE_READ = "read";
	public static final String SCOPE_WRITE = "write";

	public static final String OAUTH_TOKEN_URL = "/oauth/token";

	public static final String ACCESS_TOKEN_URL = "/oauth/token?grant_type=client_credentials";
	public static final String HTTP = "http://";

}
