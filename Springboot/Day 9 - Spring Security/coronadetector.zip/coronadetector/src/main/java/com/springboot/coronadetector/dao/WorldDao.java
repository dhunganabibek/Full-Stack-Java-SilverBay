package com.springboot.coronadetector.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.coronadetector.model.World;

public interface WorldDao extends JpaRepository<World, Integer> {

}
