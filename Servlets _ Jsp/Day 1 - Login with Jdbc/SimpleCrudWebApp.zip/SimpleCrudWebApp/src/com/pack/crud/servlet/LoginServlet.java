package com.pack.crud.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pack.crud.utils.DatabaseUtils;

public class LoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String username = request.getParameter("username");
			String password = request.getParameter("password");

			Connection connection = DatabaseUtils.getMySqlDbConnection();

			String query = "select * from login where username=? and password=?";
			PreparedStatement ps = connection.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);

			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				String userrole = rs.getString("usertype");
				if ("admin".equalsIgnoreCase(userrole)) {
					RequestDispatcher rd = request.getRequestDispatcher("admin.jsp"); //servlet/jsp/html
					rd.forward(request, response);
				} else {
					RequestDispatcher rd = request.getRequestDispatcher("user.jsp");
					rd.forward(request, response);
				}
			} else {
				PrintWriter out = response.getWriter();
				out.print("Wrong credentials , plz try again !!!");
				
				
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.include(request, response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
