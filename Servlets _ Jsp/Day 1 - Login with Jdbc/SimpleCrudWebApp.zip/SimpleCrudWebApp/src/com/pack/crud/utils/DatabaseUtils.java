package com.pack.crud.utils;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseUtils {

	public static Connection getMySqlDbConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String username = "root";
			String password = "mysql";
			String dbName = "batch8_db";
			String url = "jdbc:mysql://localhost:3306/" + dbName;
			connection = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

}
