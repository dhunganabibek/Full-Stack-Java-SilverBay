package com.pack.oops;

public class Book {

	public void name() {
		System.out.println("Core Java");
	}

	public void name(int price) {
		System.out.println("Core Java of price " + price);
	}
	
	public void name(String author) {
		System.out.println("Core Java written by " + author);
	}

}
