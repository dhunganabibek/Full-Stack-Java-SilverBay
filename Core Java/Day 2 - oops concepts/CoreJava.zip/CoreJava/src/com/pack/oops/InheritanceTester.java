package com.pack.oops;

public class InheritanceTester {

	public static void main(String[] args) {
		// step1: creating instance/object of the respective class
		Animal animal = new Animal();

		// step2: call the properties of class
		animal.eat();

		Tiger tiger = new Tiger();
		tiger.eat();
		
		//animal.teeth; //this is not a statement in java
		
		System.out.println("teeths of animal : "+animal.teeth);
		System.out.println("teeths of tiger : "+tiger.teeth);
	}

}
