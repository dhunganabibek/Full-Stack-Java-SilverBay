package com.pack.exceptionhandling;

class Wood {
	public void type() throws ClassNotFoundException {
		System.out.println("inside type method of Wood!!!");
	}
}

class Table extends Wood {
	public void type() {
		System.out.println("inside type() method of Table !!!");
	}
}

public class ExceptionWithInheritance {
	public static void main(String[] args) {
		Table table = new Table();
		table.type();
	}
}
