package com.pack.exceptionhandling;

public class TimeLimitException extends Exception {

	public TimeLimitException() {
		super();
	}

	public TimeLimitException(String exceptionMsg) {
		super(exceptionMsg);
	}

}
