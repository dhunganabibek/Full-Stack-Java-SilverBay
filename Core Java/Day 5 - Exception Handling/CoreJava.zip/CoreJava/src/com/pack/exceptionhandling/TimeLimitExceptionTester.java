package com.pack.exceptionhandling;

public class TimeLimitExceptionTester {

	public static void main(String[] args) {

		int timer = 30;

		if (timer > 40) {
			try {
				throw new TimeLimitException("timer is over 40.");
			} catch (TimeLimitException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Good to go !!!");
		}

	}

}
