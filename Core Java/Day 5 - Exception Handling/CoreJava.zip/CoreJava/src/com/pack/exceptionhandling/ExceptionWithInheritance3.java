package com.pack.exceptionhandling;

import java.io.FileNotFoundException;

class Wood3 {
	public void type() {
		System.out.println("inside type method of Wood!!!");
	}
}

class Table3 extends Wood3 {
	public void type() throws FileNotFoundException {
		System.out.println("inside type() method of Table !!!");
	}
}

public class ExceptionWithInheritance3 {
	public static void main(String[] args) {
		Table3 table3 = new Table3();
		try {
			table3.type();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
