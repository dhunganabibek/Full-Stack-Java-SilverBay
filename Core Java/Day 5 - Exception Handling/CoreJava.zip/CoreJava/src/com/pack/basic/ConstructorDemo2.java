package com.pack.basic;

class Page2 {

	private String type;

	public Page2() {
		System.out.println("inside default constructor !!!");
	}

	public Page2(String type) {
		System.out.println("inside argumented constructor !!!");
		this.type = type;
	}
	
	public Page2(String type , int no) {
		System.out.println("inside argumented constructor !!!");
		this.type = type;
	}

	public void type() {
		System.out.println("type of page : " + type);
	}
}

public class ConstructorDemo2 {
	public static void main(String[] args) {
		Page2 page2 = new Page2();
		page2.type();

		Page2 page22 = new Page2("Steel");
		page22.type();
		
	}
}
