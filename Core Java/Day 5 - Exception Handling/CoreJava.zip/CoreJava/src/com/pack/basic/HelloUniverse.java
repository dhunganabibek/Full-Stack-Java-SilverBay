package com.pack.basic;

public class HelloUniverse {

	// main method is the starting point in java
	public static void main(String[] args) {
		System.out.println("Hello universe !!!");
	}

}