package com.pack.keywords;

public class StaticKeyword1 {

	private static int x = 10;

	public static void dummy() {
		System.out.println("dummy static method !!!");
	}

	public static void main(String[] args) {
		// StaticKeyword1 ref = new StaticKeyword1();
		// ref.dummy();
		// The static method dummy() from the type StaticKeyword1 should be accessed in
		// a static way

		StaticKeyword1.dummy();

		System.out.println("value of x : " + StaticKeyword1.x);
	}

}
