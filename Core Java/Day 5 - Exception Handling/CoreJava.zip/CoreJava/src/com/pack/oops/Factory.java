package com.pack.oops;

public abstract class Factory {

	public abstract void build(); // 100 % abstraction

	// 0 % abstraction
	public void buildGlass() {
		System.out.println("building glasses !!!");
	}

}
