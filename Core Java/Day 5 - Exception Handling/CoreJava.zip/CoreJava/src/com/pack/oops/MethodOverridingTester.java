package com.pack.oops;

public class MethodOverridingTester {

	public static void main(String[] args) {
		Forest forest = new Forest();
		forest.name();
		
		Tree tree = new Tree();
		System.out.print("tree name is : ");
		tree.name();
	}

}
