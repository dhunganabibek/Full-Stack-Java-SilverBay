package com.pack.basic;

class Page {
	public Page() {
		System.out.println("inside default constructor !!!");
	}

	public void type() {
		System.out.println("type of page");
	}
}

public class ConstructorDemo1 {
	public static void main(String[] args) {
		Page page = new Page();
		page.type();
	}
}
