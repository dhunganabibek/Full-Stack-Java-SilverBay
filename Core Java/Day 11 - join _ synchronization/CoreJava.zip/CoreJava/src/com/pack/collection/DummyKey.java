package com.pack.collection;

public class DummyKey {

	private int i;

	public DummyKey() {
	}

	public DummyKey(int i) {
		this.i = i;
	}

	@Override
	public int hashCode() {
		return i;
	}

	@Override
	public String toString() {
		return i + " ";
	}

}
