package com.pack.collection;

public class Mouse implements Comparable<Mouse> {
	private int price;
	private String brand;

	public Mouse() {
	}

	public Mouse(int price, String brand) {
		this.price = price;
		this.brand = brand;
	}

	@Override
	public String toString() {
		return "Mouse [price=" + price + ", brand=" + brand + "]";
	}

	//DESC order
//	@Override
//	public int compareTo(Mouse mouse) {
//		if (mouse.price > this.price) {
//			return 1;
//		} else if (mouse.price < this.price) {
//			return -1;
//		} else {
//			return 0;
//		}
//	}
	
	//ASC
	@Override
	public int compareTo(Mouse mouse) {
		if (this.price > mouse.price) {
			return 1;
		} else if (this.price < mouse.price) {
			return -1;
		} else {
			return 0;
		}
	}

}
