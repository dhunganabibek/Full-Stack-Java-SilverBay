package com.pack.collection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListTester {
	public static void main(String[] args) {

		ArrayList<Mouse> mouses = new ArrayList<>();
		mouses.add(new Mouse(100, "HP"));
		mouses.add(new Mouse(200, "Dell"));
		mouses.add(new Mouse(300, "Apple"));
		mouses.add(new Mouse(400, "Sony"));

		// traversing
		System.out.println(mouses);

		System.out.println("--------------------------------------");

		for (Mouse mouse : mouses) {
			System.out.println(mouse);
		}

		System.out.println("--------------------------------------");
		
		Iterator<Mouse> iterator = mouses.iterator();

		while (iterator.hasNext()) {
			Mouse mouse = (Mouse) iterator.next();
			System.out.println(mouse);
		}
		
	}
}
