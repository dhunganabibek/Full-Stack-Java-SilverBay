package com.pack.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CheckedExceptionEx2 {

	public static void main(String[] args) throws FileNotFoundException {

		FileInputStream fis = new FileInputStream("c://temp.txt");

	}

}
