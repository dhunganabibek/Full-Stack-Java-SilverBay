package com.pack.multithreading;

class MyThread3 implements Runnable {

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			Thread.currentThread().setName("Child Thread");
			System.out.println(Thread.currentThread().getName() + " = " + i);
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}


public class SleepExample2 {

	public static void main(String[] args) throws InterruptedException {

		MyThread3 myThread = new MyThread3();
		Thread thread = new Thread(myThread);
		thread.start();
		
		for (int i = 1; i <= 10; i++) {		
			System.out.println(Thread.currentThread().getName() + " = " + i);
			//Thread.sleep(1); //1000ms = 1s
		}
 
	}

}
