package com.pack.multithreading;

class Display {
	// public synchronized void wish(String name) {
	// for (int i = 1; i <= 10; i++) {
	// System.out.print("Good morning : ");
	// try {
	// Thread.sleep(5);
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// System.out.println(name);
	// }
	// }

	public void wish(String name) {
		System.out.println("first statement !!!");
		synchronized (this) {
			for (int i = 1; i <= 10; i++) {
				System.out.print("Good morning : ");
				try {
					Thread.sleep(5);
				} catch (Exception e) {
					e.printStackTrace();
				}
				System.out.println(name);
			}
		}
		System.out.println("last statement !!!");
	}

}

class CustomThread extends Thread {
	private Display display;
	private String name;

	public CustomThread() {
	}

	public CustomThread(Display display, String name) {
		this.display = display;
		this.name = name;
	}

	public void run() {
		display.wish(name);
	}
}

public class SynchronizationDemo {
	public static void main(String[] args) throws InterruptedException {
		Display display = new Display();
		String name1 = "Ram";
		String name2 = "Shyam";
		CustomThread t1 = new CustomThread(display, name1);
		CustomThread t2 = new CustomThread(display, name2);
		t1.start();
		t2.start();
		// t2.join();
	}
}
