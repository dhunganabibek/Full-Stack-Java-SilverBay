package com.pack.multithreading;

public class SleepExample {

	public static void main(String[] args) throws InterruptedException {

		for (int i = 1; i <= 10; i++) {		
			System.out.println(Thread.currentThread().getName() + " = " + i);
			Thread.sleep(500); //1000ms = 1s
		}
 
	}

}
