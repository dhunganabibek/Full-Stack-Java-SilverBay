package com.pack.multithreading;

class MyThread2 implements Runnable {
	@Override
	public void run() {
		try {
			Thread.currentThread().join(10);
			for (int i = 1; i <= 10; i++) {
				Thread.currentThread().setName("Child Thread");
				System.out.println(Thread.currentThread().getName() + " = " + i);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}

public class ThreadExampleWithJoin {
	public static void main(String[] args) {
		MyThread2 myThread = new MyThread2();
		Thread thread = new Thread(myThread);
		thread.start();

		for (int i = 1; i <= 10; i++) {
			System.out.println(Thread.currentThread().getName() + " = " + i);
		}

	}

}
