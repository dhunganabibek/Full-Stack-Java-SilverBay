package com.pack.multithreading;

public class ThreadExample {

	public static void main(String[] args) {

		System.out.println("Current thread name : " + Thread.currentThread().getName());
		System.out.println("Current thread Id : " + Thread.currentThread().getId());
		System.out.println("Current thread priority : " + Thread.currentThread().getPriority());
		System.out.println("Current thread state : " + Thread.currentThread().getState());

		 //daemon
	}

}
