package com.pack.oops;

public class Triangle implements Shape {

	public int min = 10;
	
	public final static int  mini = 5;
	
	@Override
	public void draw() {
		System.out.println("triangle is drawn !!!");
	}

}
