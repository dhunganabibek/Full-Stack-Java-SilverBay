package com.pack.exceptionhandling;

// java.lang pkg is the default pkg.  

public class TimeLimitException extends RuntimeException {

	public TimeLimitException() {
		super();
	}

	public TimeLimitException(String exceptionMsg) {
		super(exceptionMsg);
	}

}
