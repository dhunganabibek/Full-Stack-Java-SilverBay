package com.pack.exceptionhandling;

public class FinallyDemo1 {

	public static void main(String[] args) {
		System.out.println("statement 1");
		try {
			System.out.println("statement 2");
			int d = 5 / 0;
		} catch (Exception e) {
			System.out.println("statement 3 (catch block)");
		} finally {
			System.out.println("statement 4");
		}
		System.out.println("statement 5");
	}

}
