package com.pack.collection;

import java.util.Collection;
import java.util.Collections;
import java.util.Hashtable;
import java.util.Set;

public class HashTableDemo {

	public static void main(String[] args) {
		Hashtable<Integer, String> hashtable = new Hashtable<Integer, String>();

		hashtable.put(10, "Abc");
		hashtable.put(2, "sdf");
		hashtable.put(4, "tgr");
		hashtable.put(6, "eds");
		hashtable.put(90, "qwe");
		hashtable.put(90, "sdf");

		System.out.println(hashtable);

		// key+"="+value+","+ key+"="+value...

		System.out.println(hashtable.get(90));

		System.out.println("---------all keys-------");

		Set<Integer> keys = hashtable.keySet();
		for (Integer key : keys) {
			System.out.println(key);
		}
		System.out.println("---------all vaules-------");

		Collection<String> values = hashtable.values();
		for (String value : values) {
			System.out.println(value);
		}

		System.out.println("--------BOTH K-V--------------");
		Set set = hashtable.entrySet();  //HW
	}

}
