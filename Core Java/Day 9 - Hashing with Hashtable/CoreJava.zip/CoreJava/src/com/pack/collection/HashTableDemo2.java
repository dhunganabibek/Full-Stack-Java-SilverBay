package com.pack.collection;

import java.util.Hashtable;

public class HashTableDemo2 {

	public static void main(String[] args) {
		Hashtable<Bag, String> hashtable = new Hashtable<>();

		hashtable.put(new Bag(10, 20), "Abc");
		hashtable.put(new Bag(55, 66), "sdf");
		hashtable.put(new Bag(77, 33), "tgr");
		hashtable.put(new Bag(44, 22), "eds");

		System.out.println(hashtable);

		// key+"="+value+","+ key+"="+value...

		System.out.println(hashtable.get(new Bag(44, 22)));
		
		//traversing
		//keys
		//values
		//both K-V
	}

}
