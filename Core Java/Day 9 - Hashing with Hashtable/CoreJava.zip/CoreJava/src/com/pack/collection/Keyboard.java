package com.pack.collection;

public class Keyboard {
	private int price;
	private String brand;

	public Keyboard() {
	}

	public Keyboard(int price, String brand) {
		this.price = price;
		this.brand = brand;
	}

	public int getPrice() {
		return price;
	}

	public String getBrand() {
		return brand;
	}

	@Override
	public String toString() {
		return "Mouse [price=" + price + ", brand=" + brand + "]";
	}

}
