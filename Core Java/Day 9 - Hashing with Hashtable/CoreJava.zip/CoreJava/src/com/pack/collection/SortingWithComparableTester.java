package com.pack.collection;

import java.util.ArrayList;
import java.util.Collections;

public class SortingWithComparableTester {
	public static void main(String[] args) {

		ArrayList<Mouse> mouses = new ArrayList<>();
		mouses.add(new Mouse(100, "HP"));
		mouses.add(new Mouse(300, "Apple"));
		mouses.add(new Mouse(1000, "Logitech"));
		mouses.add(new Mouse(200, "Dell"));
		mouses.add(new Mouse(400, "Sony"));

		System.out.println("----------before sorting---------------");
		System.out.println(mouses);

		System.out.println("----------after sorting---------------");
		Collections.sort(mouses);
		System.out.println(mouses);
	}
}
