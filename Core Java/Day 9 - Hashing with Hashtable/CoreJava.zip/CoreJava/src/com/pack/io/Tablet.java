package com.pack.io;

import java.io.Serializable;

public class Tablet implements Serializable {

	private static final long serialVersionUID = 1545641565484L;

	private int price;
	private String name;

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Tablet [price=" + price + ", name=" + name + "]";
	}

}
