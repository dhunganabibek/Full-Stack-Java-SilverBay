package com.pack.oops;

public class Forest {

	public void name() {
		System.out.println("amazon forest");
	}

}
