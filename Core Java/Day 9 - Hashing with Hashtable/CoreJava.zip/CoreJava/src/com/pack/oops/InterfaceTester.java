package com.pack.oops;

public class InterfaceTester {

	public static void main(String[] args) {
		// Shape shape = new Shape(); //Cannot instantiate the type Shape
		Triangle triangle = new Triangle();
		triangle.draw();

		System.out.println("max value from Shape  : " + Shape.max);
		System.out.println("min value from Triangle  : " + triangle.min);
		System.out.println("mini value from Triangle  : " + Triangle.mini);

	}

}
