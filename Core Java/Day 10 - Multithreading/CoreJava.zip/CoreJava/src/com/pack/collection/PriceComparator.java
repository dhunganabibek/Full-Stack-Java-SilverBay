package com.pack.collection;

import java.util.Comparator;

public class PriceComparator implements Comparator<Keyboard> {

	//ASC
//	@Override
//	public int compare(Keyboard kb1, Keyboard kb2) {
//		if (kb1.getPrice() > kb2.getPrice()) {
//			return 1;
//		} else if (kb1.getPrice() < kb2.getPrice()) {
//			return -1;
//		} else {
//			return 0;
//		}
//	}
	
	//DESC
	@Override
	public int compare(Keyboard kb1, Keyboard kb2) {
		if (kb2.getPrice() > kb1.getPrice()) {
			return 1;
		} else if (kb2.getPrice() < kb1.getPrice()) {
			return -1;
		} else {
			return 0;
		}
	}

}
