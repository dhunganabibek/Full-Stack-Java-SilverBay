package com.pack.collection;

import java.util.Comparator;

public class BrandComparator implements Comparator<Keyboard> {

	// ASC
	// @Override
	// public int compare(Keyboard kb1, Keyboard kb2) {
	// if (kb1.getPrice() > kb2.getPrice()) {
	// return 1;
	// } else if (kb1.getPrice() < kb2.getPrice()) {
	// return -1;
	// } else {
	// return 0;
	// }
	// }

	// DESC
	@Override
	public int compare(Keyboard kb1, Keyboard kb2) {
		return kb2.getBrand().compareTo(kb1.getBrand());
	}

}
