package com.pack.collection;

import java.util.ArrayList;
import java.util.Collections;

public class SortingTester {
	public static void main(String[] args) {

		ArrayList<Integer> integers = new ArrayList<>();
		integers.add(1);
		integers.add(4);
		integers.add(2);
		integers.add(10);
		integers.add(3);

		System.out.println("----------before sorting");
		System.out.println(integers);

		// by default ASCENDING order
		System.out.println("-------after sorting");
		Collections. sort(integers);
		System.out.println(integers);

	}
}
