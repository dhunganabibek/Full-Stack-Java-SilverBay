package com.pack.collection;

import java.util.Hashtable;

public class HashTableDemo3 {

	public static void main(String[] args) {
		Hashtable<DummyKey, String> hashtable = new Hashtable<>(15);

		hashtable.put(new DummyKey(5), "A");
		hashtable.put(new DummyKey(2), "B");
		hashtable.put(new DummyKey(6), "C");
		hashtable.put(new DummyKey(15), "D");
		hashtable.put(new DummyKey(23), "E");
		hashtable.put(new DummyKey(16), "F");

		System.out.println(hashtable);
		// 6=c,16=f ,5=a , 15=D , 2=B , 23=E
	}

}
