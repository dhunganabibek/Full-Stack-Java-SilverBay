package com.pack.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class DeSerializationTester {

	public static void main(String[] args) {

		String filePath = "E:\\Session\\Batch-8\\Tablet.ser";
		try {
			FileInputStream fis = new FileInputStream(filePath);

			ObjectInputStream ois = new ObjectInputStream(fis);
			Tablet tablet = (Tablet) ois.readObject();

			System.out.println("-----"+tablet);

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
