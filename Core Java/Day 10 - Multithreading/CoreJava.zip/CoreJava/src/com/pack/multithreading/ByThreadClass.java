package com.pack.multithreading;

class CustomThread1 extends Thread {

	public void run() {
		System.out.println("from CustomThread1 !!!!");
	}

}

public class ByThreadClass {

	public static void main(String[] args) {
		CustomThread1 t1 = new CustomThread1();
		t1.start();

		System.out.println("from main method !!!");
	}

}
