package com.pack.multithreading;

class MyThread implements Runnable {

	@Override
	public void run() {
		for (int i = 1; i <= 10; i++) {
			System.out.println(Thread.currentThread().getName() + " = " + i);
		}
	}

}

public class ThreadExample2 {

	public static void main(String[] args) {

		MyThread myThread = new MyThread();
		Thread thread = new Thread(myThread);
		thread.start();

		for (int i = 1; i <= 10; i++) {
			System.out.println(Thread.currentThread().getName() + " = " + i);
		}

	}

}
