package com.pack.multithreading;

class CustomThread2 implements Runnable {

	public void run() {
		System.out.println("from CustomThread2 !!!!");
	}

}

public class ByThreadClass2 {

	public static void main(String[] args) {
		CustomThread2 customThread = new CustomThread2();
		Thread thread = new Thread(customThread);
		thread.start();
		
		System.out.println("from main method !!!");
	}

}
