package com.pack.keywords;

public class StaticKeyword2 {

	private static int x = 10;

	private int y = 10;

	public static void dummy() {
		System.out.println("dummy static method !!!");
		//funny(); //Cannot make a static reference to the non-static method funny() from the type StaticKeyword2
	}

	public void funny() {
		System.out.println("funny method !!!");
		dummy();
	}

	public static void main(String[] args) {
		// StaticKeyword1 ref = new StaticKeyword1();
		// ref.dummy();
		// The static method dummy() from the type StaticKeyword1 should be accessed in
		// a static way

		StaticKeyword2.dummy();
		System.out.println("value of x : " + StaticKeyword2.x);

		StaticKeyword2 ref = new StaticKeyword2();
		ref.funny();

		System.out.println("value of y : " + ref.y);
	}

}
