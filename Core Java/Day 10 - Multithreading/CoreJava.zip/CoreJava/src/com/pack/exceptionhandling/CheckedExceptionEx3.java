package com.pack.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CheckedExceptionEx3 {

	public static void main(String[] args) {
		try {
			m1();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	private static void m1() throws FileNotFoundException {
		FileInputStream fis = new FileInputStream("c://temp.txt");
	}

}
