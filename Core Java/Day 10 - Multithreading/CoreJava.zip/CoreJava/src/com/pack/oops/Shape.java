package com.pack.oops;

public interface Shape {

	public void draw();
	
	public int max = 100;

}
