package com.pack.oops;

public class Animal {

	public int teeth = 20;

	public void eat() {
		// sysout => ctrl + space
		System.out.println("animal is eating");
	}

}
