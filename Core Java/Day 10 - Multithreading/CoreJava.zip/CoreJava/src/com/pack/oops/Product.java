package com.pack.oops;

public class Product extends Factory {

	@Override
	public void build() {
		System.out.println("building product !!!");
	}

}
