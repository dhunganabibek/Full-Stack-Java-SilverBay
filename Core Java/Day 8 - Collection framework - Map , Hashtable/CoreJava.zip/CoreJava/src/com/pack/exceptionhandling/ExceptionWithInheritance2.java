package com.pack.exceptionhandling;

import java.io.FileNotFoundException;

class Wood2 {
	public void type() throws FileNotFoundException {
		System.out.println("inside type method of Wood!!!");
	}
}

class Table2 extends Wood2 {
	public void type()  {
		System.out.println("inside type() method of Table !!!");
	}
}

public class ExceptionWithInheritance2 {
	public static void main(String[] args) {
		Table2 table2 = new Table2();
		table2.type();
	}
}
