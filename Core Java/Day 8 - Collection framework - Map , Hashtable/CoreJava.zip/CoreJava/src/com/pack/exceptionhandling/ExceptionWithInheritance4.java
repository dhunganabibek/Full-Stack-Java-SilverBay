package com.pack.exceptionhandling;

class Wood4 {
	public void type() {
		System.out.println("inside type method of Wood!!!");
	}
}

class Table4 extends Wood4 {
	public void type() throws NullPointerException {
		System.out.println("inside type() method of Table !!!");
	}
}

public class ExceptionWithInheritance4 {
	public static void main(String[] args) {
		Table4 table4 = new Table4();
		table4.type();
	}
}
