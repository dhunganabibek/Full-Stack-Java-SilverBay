package com.pack.io;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializationTester {

	public static void main(String[] args) {		
		String filePath = "E:\\Session\\Batch-8\\Tablet.ser";

		try {
			FileOutputStream fos = new FileOutputStream(filePath);
			
			Tablet tablet = new Tablet();
			tablet.setPrice(1453);
			tablet.setName("Applefghfghf");

			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(tablet);

			System.out.println("tablet object is serialized!!!");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
