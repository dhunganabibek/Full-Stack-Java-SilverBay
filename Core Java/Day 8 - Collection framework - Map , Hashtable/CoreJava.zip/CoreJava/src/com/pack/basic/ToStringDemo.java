package com.pack.basic;

class Photo {
	private int width;
	private int height;

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	@Override
	public String toString() {
		return "Photo [width=" + width + ", height=" + height + "]";
	}

//	public String toString() {
//		return "height = " + height + " , width = " + width;
//	}
	
}

public class ToStringDemo {
	public static void main(String[] args) {
		Photo photo = new Photo();
		photo.setHeight(20);
		photo.setWidth(30);

		System.out.println(photo);
	}
}
