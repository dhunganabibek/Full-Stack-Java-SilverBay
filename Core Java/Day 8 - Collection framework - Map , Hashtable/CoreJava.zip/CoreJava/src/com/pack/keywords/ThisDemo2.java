package com.pack.keywords;

class Remote2 {
	public Remote2() {
		System.out.println("default constructor");
	}

	public Remote2(int a) {
		this();
		System.out.println("one arg of int type constructor");
	}

	public Remote2(String s) {
		this(5);
		System.out.println("one arg of String type constructor");
	}

	public Remote2(int a, String s) {
		this("y");
		System.out.println("two arg constructor");
	}
}

public class ThisDemo2 {
	public static void main(String[] args) {
		Remote2 remote = new Remote2(3, "w");
	}
}
