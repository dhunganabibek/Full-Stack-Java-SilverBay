package com.pack.oops;

public class Tiger extends Animal {

}
