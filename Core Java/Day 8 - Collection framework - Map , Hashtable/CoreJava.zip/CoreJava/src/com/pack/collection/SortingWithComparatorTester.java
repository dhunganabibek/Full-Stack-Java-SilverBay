package com.pack.collection;

import java.util.ArrayList;
import java.util.Collections;

public class SortingWithComparatorTester {
	public static void main(String[] args) {

		ArrayList<Keyboard> keyboards = new ArrayList<>();
		keyboards.add(new Keyboard(100, "HP"));
		keyboards.add(new Keyboard(300, "Apple"));
		keyboards.add(new Keyboard(1000, "Logitech"));
		keyboards.add(new Keyboard(200, "Dell"));
		keyboards.add(new Keyboard(400, "Sony"));

		System.out.println("----------before sorting---------------");
		System.out.println(keyboards);

		System.out.println("----------after sorting with price (DESC)---------------");
		Collections.sort(keyboards, new PriceComparator());
		System.out.println(keyboards);

		System.out.println("----------after sorting with brand (DESC)---------------");
		Collections.sort(keyboards, new BrandComparator());
		System.out.println(keyboards);
	}
}
