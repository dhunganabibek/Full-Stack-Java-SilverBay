package com.pack.collection;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ArrayListTester2 {
	public static void main(String[] args) {

		ArrayList<Integer> integers = new ArrayList<>();
		integers.add(3);
		integers.add(6);
		integers.add(9);
		integers.add(10);

		// traversing
		System.out.println(integers);

		System.out.println("---------------");
		
		int i[] = { 1, 5, 6, 8, 0 }; // one way of creating arrays;

		List<int[]> ints = Arrays.asList(i);
//		System.out.println(ints);
		
		for (int[] js : ints) {
			for (int js2 : js) {
				System.out.println(js2);
			}
		}
		
		
	}
}
