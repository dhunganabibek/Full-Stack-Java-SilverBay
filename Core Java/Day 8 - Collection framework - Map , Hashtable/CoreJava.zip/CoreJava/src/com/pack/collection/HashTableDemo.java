package com.pack.collection;

import java.util.Hashtable;

public class HashTableDemo {

	public static void main(String[] args) {
		Hashtable<Integer, String> hashtable = new Hashtable<Integer, String>();
		
		hashtable.put(10, "Abc");
		hashtable.put(2, "sdf");
		hashtable.put(4, "tgr");
		hashtable.put(6, "eds");
		hashtable.put(90, "qwe");
		hashtable.put(90, "sdf");
		
		System.out.println(hashtable);
		
		//key+"="+value+","+ key+"="+value... 
		
		System.out.println(hashtable.get(90));
	}
	
}
