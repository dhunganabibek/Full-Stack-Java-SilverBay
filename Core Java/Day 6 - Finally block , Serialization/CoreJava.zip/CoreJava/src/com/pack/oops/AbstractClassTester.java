package com.pack.oops;

public class AbstractClassTester {

	public static void main(String[] args) {
		// Factory factory = new Factory(); //Cannot instantiate the type Factory

		Product product = new Product();
		product.build();
		product.buildGlass();

	}

}
