package com.pack.keywords;

class Remote {
	public Remote() {
		this(5);
		System.out.println("default constructor");		
	}
	
	public Remote(byte b) {
		System.out.println("byte constructor");
	}

	public Remote(int a) {
		this("s");
		System.out.println("one arg of int type constructor");
	}

	public Remote(String s) {
		this(5,"rr");
		System.out.println("one arg of String type constructor");
	}

	public Remote(int a, String s) {
		System.out.println("two arg constructor");
	}

}

public class ThisDemo1 {
	public static void main(String[] args) {
		Remote remote = new Remote();
	}
}
