package com.pack.exceptionhandling;

public class TimeLimitException extends RuntimeException {

	public TimeLimitException() {
		super();
	}

	public TimeLimitException(String exceptionMsg) {
		super(exceptionMsg);
	}

}
