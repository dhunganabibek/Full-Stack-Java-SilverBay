package com.pack.exceptionhandling;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class CheckedExceptionEx1 {

	public static void main(String[] args) {

		try {
			FileInputStream fis = new FileInputStream("c://temp.txt");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
