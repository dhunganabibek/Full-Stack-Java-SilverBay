package com.pack.oops;

public class MethodOverloadingTester {

	public static void main(String[] args) {
		Book book = new Book();
		book.name();
		book.name(500);
		book.name("ABX");
	}

}
