package com.pack.oops;

public class Tree extends Forest {

	public void name() {
		System.out.println(" Pine Tree ");
	}

}
