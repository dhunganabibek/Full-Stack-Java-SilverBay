package com.pack.basic;

public class Addition {

	public static void main(String[] args) {
		int x = 5;
		int y = 9;
		int z = add(x, y);
		System.out.println("z = " + z);
	}

	private static int add(int x, int y) {
		int c = x + y;
		System.out.println("value of c = " + c);
		return c;
	}

}
