package com.pack.spmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.spmvc.vo.RegisterVO;

@Controller
public class RegisterController {

	// loading register.jsp page
	@RequestMapping(method = RequestMethod.GET, value = "/loadRegisterPage")
	public String loadRegisterPage(Model model) {
		model.addAttribute("registerVO", new RegisterVO());
		return "register";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/register")
	public String register(@ModelAttribute(value = "registerVO") RegisterVO registerVO, BindingResult result) {
		System.out.println("username" + registerVO.getUsername());
		System.out.println("password" + registerVO.getPassword());
		return "admin";
	}

}
