package com.pack.spmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {

	@RequestMapping(method = RequestMethod.GET, value = "/hello")
	public void hello() {
		System.out.println("hello from HelloController !!!");
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/welcome")
	public void welcome() {
		System.out.println("welcome to HelloController !!!");
	}

}
