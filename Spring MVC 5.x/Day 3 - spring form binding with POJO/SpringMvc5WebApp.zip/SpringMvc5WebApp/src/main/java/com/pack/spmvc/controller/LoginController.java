package com.pack.spmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController {

//	@RequestMapping(method = RequestMethod.POST, value = "/login")
//	public String login(@RequestParam String username , @RequestParam String password) {
//		System.out.println("login from LoginController !!!");
//		System.out.println("username : "+username);
//		System.out.println("password : "+password);
//		return "admin";
//	}

	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public ModelAndView login(@RequestParam String username, @RequestParam String password) {
		System.out.println("login from LoginController !!!");
		System.out.println("username : " + username);
		System.out.println("password : " + password);
		ModelAndView modelAndView = new ModelAndView("admin");
		modelAndView.addObject("username", username);
		modelAndView. addObject("password", password);
		return modelAndView;
		//ModelMap
	}

}
