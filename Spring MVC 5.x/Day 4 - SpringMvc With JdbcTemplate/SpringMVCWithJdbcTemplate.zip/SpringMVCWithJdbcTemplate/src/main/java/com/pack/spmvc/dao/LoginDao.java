package com.pack.spmvc.dao;

import com.pack.spmvc.vo.LoginVO;

public interface LoginDao {

	public LoginVO login(LoginVO loginVO);

}
