package com.pack.spmvc.service;

import com.pack.spmvc.vo.LoginVO;

public interface LoginService {

	public LoginVO login(LoginVO loginVO);

}
