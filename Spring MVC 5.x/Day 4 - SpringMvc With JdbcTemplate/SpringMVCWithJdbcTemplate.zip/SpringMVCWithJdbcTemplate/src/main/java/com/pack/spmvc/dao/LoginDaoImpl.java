package com.pack.spmvc.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.pack.spmvc.vo.LoginVO;

@Repository
public class LoginDaoImpl implements LoginDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public LoginVO login(LoginVO loginVO) {
		LoginVO resLoginVO = new LoginVO();
		try {
			String username = jdbcTemplate.queryForObject("select username from login_tb where username='"
					+ loginVO.getUsername() + "' and " + " password = '" + loginVO.getPassword() + "'", String.class);
			if (username != null && !username.equals("")) {
				resLoginVO.setUsername(username);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resLoginVO;
	}

}
