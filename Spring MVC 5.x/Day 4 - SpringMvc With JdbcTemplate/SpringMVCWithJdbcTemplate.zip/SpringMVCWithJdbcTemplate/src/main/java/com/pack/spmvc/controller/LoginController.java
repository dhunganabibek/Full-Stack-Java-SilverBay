package com.pack.spmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.pack.spmvc.service.LoginService;
import com.pack.spmvc.vo.LoginVO;

@Controller
public class LoginController {

	@Autowired
	private LoginService loginService;

	// loading login.jsp page
	@RequestMapping(method = RequestMethod.GET, value = "/loadLoginPage")
	public String loadLoginPage(Model model) {
		model.addAttribute("loginVO", new LoginVO());
		return "login";
	}

	// following method executes when login button click is clicked in login.jsp
	// page
	@RequestMapping(method = RequestMethod.POST, value = "/login")
	public String login(@ModelAttribute(value = "loginVO") LoginVO loginVO, BindingResult result) {
		LoginVO resLoginVO = loginService.login(loginVO);
		return resLoginVO.getViewName();
	}

}
