package com.pack.spmvc.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pack.spmvc.dao.LoginDao;
import com.pack.spmvc.vo.LoginVO;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao; // loosely coupled

	public LoginVO login(LoginVO loginVO) {
		LoginVO resLoginVO = loginDao.login(loginVO);
		if (resLoginVO.getUsername() != null && !resLoginVO.getUsername().equals("")) {
			resLoginVO.setViewName("admin");
		}else {
			resLoginVO.setViewName("login");
		}
		return resLoginVO;
	}

}
